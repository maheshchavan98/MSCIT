# Import PyTorch
import torch
def create_tensor(shape, dtype=torch.float32):
 tensor = torch.arange(shape[0] * shape[1], dtype=dtype).reshape(shape)
 print(f"Original Tensor with shape {shape} and datatype {dtype}:")
 print(tensor)
 return tensor
def perform_operations(tensor):
 # Reshape the tensor
 reshaped_tensor = tensor.reshape(-1, 2)
 print("\nReshaped Tensor (-1, 2):")
 print(reshaped_tensor)
 # Slice the tensor (Extract 1st row and 1st 2 columns)
 sliced_tensor = tensor[0, :2]
 print("\nSliced Tensor (1st row, 1st 2 columns):")
 print(sliced_tensor)
 # Extract specific elements (e.g., element at (1,1))
 specific_element = tensor[1, 1]
 print("\nSpecific Element at (1,1):")
 print(specific_element)
# Example: Create a 2x3 tensor of float32
demo_shape = (2, 3)
demo_dtype = torch.float32
tensor = create_tensor(demo_shape, demo_dtype)
# Perform reshape, slice, and extract operations
perform_operations(tensor)