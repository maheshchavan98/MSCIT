# STEP 1: Install and Import Libraries
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Flatten, Reshape
# STEP 2: Load MNIST Data
(x_train, _), (x_test, _) = mnist.load_data()
x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0
# Flatten the images (28x28 -> 784)
x_train = x_train.reshape((len(x_train), 28 * 28))
x_test = x_test.reshape((len(x_test), 28 * 28))
# STEP 3: Define Autoencoder Model
# Encoding part
input_img = Input(shape=(784,))
encoded = Dense(128, activation='relu')(input_img)
encoded = Dense(64, activation='relu')(encoded)
encoded = Dense(32, activation='relu')(encoded) # bottleneck
# Decoding part
decoded = Dense(64, activation='relu')(encoded)
decoded = Dense(128, activation='relu')(decoded)
decoded = Dense(784, activation='sigmoid')(decoded)
# Autoencoder
autoencoder = Model(input_img, decoded)
# STEP 4: Compile Model
autoencoder.compile(optimizer='adam', loss='binary_crossentropy')
# STEP 5: Train the Autoencoder
autoencoder.fit(
 x_train, x_train,
 epochs=10,
 batch_size=256,
 shuffle=True,
 validation_data=(x_test, x_test)
)
# STEP 6: Encode and Decode Test Images
decoded_imgs = autoencoder.predict(x_test)
# STEP 7: Display Original and Reconstructed Images
n = 10
plt.figure(figsize=(20, 4))
for i in range(n):
 # Original
 ax = plt.subplot(2, n, i + 1)
 plt.imshow(x_test[i].reshape(28, 28), cmap='gray')
 plt.title("Original")
 plt.axis("off")
 # Reconstructed
 ax = plt.subplot(2, n, i + 1 + n)
 plt.imshow(decoded_imgs[i].reshape(28, 28), cmap='gray')
 plt.title("Reconstructed")
 plt.axis("off")
plt.show()