# Step 1: Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense
# Step 2: Load and preprocess the data
data = load_breast_cancer()
X = data.data
X = StandardScaler().fit_transform(X) # Normalize
# Step 3: Split data
X_train, X_test = train_test_split(X, test_size=0.2, random_state=42)
# Step 4: Build the Autoencoder
input_dim = X.shape[1] # 30 features
encoding_dim = 10 # compressed to 10 features
input_layer = Input(shape=(input_dim,))
encoded = Dense(encoding_dim, activation='relu')(input_layer)
decoded = Dense(input_dim, activation='sigmoid')(encoded)
autoencoder = Model(inputs=input_layer, outputs=decoded)
# Step 5: Compile the model
autoencoder.compile(optimizer='adam', loss='mse')
# Step 6: Train the model
history = autoencoder.fit(X_train, X_train,
 epochs=50,
 batch_size=16,
 shuffle=True,
 validation_data=(X_test, X_test),
 verbose=0)
# Step 7: Encode and Decode the test data
encoded_data = autoencoder.predict(X_test)
decoded_data = autoencoder.predict(X_test)
# Step 8: Visualize reconstruction error
reconstruction_error = np.mean(np.square(X_test - decoded_data), axis=1)
plt.hist(reconstruction_error, bins=30, color='skyblue')
plt.title("Reconstruction Error")
plt.xlabel("Error")
plt.ylabel("Frequency")
plt.show()
