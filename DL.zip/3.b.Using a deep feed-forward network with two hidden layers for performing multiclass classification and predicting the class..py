import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
# Load Iris dataset (a common multiclass dataset with 3 classes)
iris = datasets.load_iris()
X = iris.data
y = iris.target.reshape(-1, 1)
# One-hot encode the labels
encoder = OneHotEncoder(sparse_output=False)
y_encoded = encoder.fit_transform(y)
# Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2,
random_state=42)
# Build a simple deep forward network model
model = keras.Sequential([
 layers.Dense(64, activation='relu', input_shape=(4,)),
 layers.Dense(32, activation='relu'),
 layers.Dense(3, activation='softmax')
])
# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
# Train the model
model.fit(X_train, y_train, epochs=50, batch_size=16, verbose=1)
# Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {accuracy * 100:.2f}%")
# Predict the class for test data
predictions = model.predict(X_test)
predicted_classes = np.argmax(predictions, axis=1)
actual_classes = np.argmax(y_test, axis=1)
print("\nPredicted Classes:", predicted_classes)
print("Actual Classes:", actual_classes)
