
#pip install torch torchvision torchaudio
# Import PyTorch
import torch
def create_tensor(shape, dtype=torch.float32):
 # Create tensor with given shape and datatype
 tensor = torch.zeros(shape, dtype=dtype)
 print(f"Tensor with shape {shape} and datatype {dtype} created:")
 print(tensor)
# Example: Create a 2x3 tensor of float32
demo_shape = (2, 3)
demo_dtype = torch.float32
create_tensor(demo_shape, demo_dtype)
