# Import TensorFlow
import tensorflow as tf
# Perform Matrix Multiplication
def matrix_multiplication(A, B):
 result = tf.linalg.matmul(A, B)
 print("Matrix Multiplication Result:")
 print(result.numpy())
# Find Eigenvalues and Eigenvectors
def find_eigen(A):
 eigenvalues, eigenvectors = tf.linalg.eigh(A)
 print("Eigenvalues:")
 print(eigenvalues.numpy())
 print("Eigenvectors:")
 print(eigenvectors.numpy())
# Example Matrices (2x2)
A = tf.constant([[4.0, -2.0], [1.0, 1.0]], dtype=tf.float32)
B = tf.constant([[1.0, 2.0], [3.0, 4.0]], dtype=tf.float32)
# Perform Operations
matrix_multiplication(A, B)
find_eigen(A)