import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# Generate dataset
np.random.seed(42)

# House size in sq ft
house_size = np.linspace(500, 4000, 100).reshape(-1, 1).astype(np.float32)

# Price in $1000s
house_price = 50 + 0.1 * house_size + np.random.normal(0, 10, (100, 1)).astype(np.float32)

# Normalize data
house_size_norm = (house_size - np.mean(house_size)) / np.std(house_size)
house_price_norm = (house_price - np.mean(house_price)) / np.std(house_price)

# Model parameters
W = tf.Variable(tf.random.normal([1, 1], dtype=tf.float32))
b = tf.Variable(tf.random.normal([1], dtype=tf.float32))

# Linear regression model
def linear_regression(X):
    return tf.matmul(X, W) + b

# Loss function
def loss_fn(y_true, y_pred):
    return tf.reduce_mean(tf.square(y_true - y_pred))

# Optimizer
optimizer = tf.optimizers.SGD(learning_rate=0.01)

# Training step
def train_step(X, y):
    with tf.GradientTape() as tape:
        y_pred = linear_regression(X)
        loss = loss_fn(y, y_pred)

    gradients = tape.gradient(loss, [W, b])
    optimizer.apply_gradients(zip(gradients, [W, b]))

    return loss

# Training loop
epochs = 200
loss_history = []

for epoch in range(epochs):
    loss = train_step(house_size_norm, house_price_norm)
    loss_history.append(loss.numpy())

    if epoch % 20 == 0:
        print(f"Epoch {epoch}, Loss: {loss.numpy():.4f}")

# Plot Loss + Regression Line
plt.figure(figsize=(12, 5))

# Loss graph
plt.subplot(1, 2, 1)
plt.plot(range(epochs), loss_history, label='Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.legend()

# Regression graph (denormalized)
plt.subplot(1, 2, 2)
plt.scatter(house_size, house_price, label='Data')

predicted_price = (linear_regression(house_size_norm).numpy() * np.std(house_price)) + np.mean(house_price)

plt.plot(house_size, predicted_price, label='Fitted Line')
plt.xlabel('House Size (sq ft)')
plt.ylabel('House Price ($1000s)')
plt.title('Learned Linear Relationship')
plt.legend()

plt.show()

# Final parameters
print(f"Trained Weight: {W.numpy()[0][0]:.4f}, Bias: {b.numpy()[0]:.4f}")