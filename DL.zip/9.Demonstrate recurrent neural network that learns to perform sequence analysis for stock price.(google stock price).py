#pip install yfinance --quiet
import yfinance as yf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
# Step 2: Download Google (GOOG) stock data
df = yf.download('GOOG', start='2020-01-01', end='2024-12-31')
df = df[['Open', 'Close', 'High', 'Low']] # Focus on OC2,0C3,0C4
# Step 3: Normalize data
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(df)
# Step 4: Create sequences for training
def create_sequences(data, seq_length=60):
    x, y = [], []
    for i in range(len(data) - seq_length):
        x.append(data[i:i+seq_length])
        y.append(data[i+seq_length]) # predict next time step
    return np.array(x), np.array(y)

sequence_length = 60
X, y = create_sequences(scaled_data, sequence_length)
# Step 5: Split into train/test sets
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]
# Step 6: Build RNN model with LSTM
model = Sequential([
 LSTM(64, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])),
 LSTM(32),
 Dense(4) # Predicting Open, Close, High, Low
])
model.compile(optimizer='adam', loss='mse')
model.summary()
# Step 7: Train model
history = model.fit(X_train, y_train, epochs=20, batch_size=32, validation_data=(X_test,
y_test))
# Step 8: Plot training history
plt.plot(history.history['loss'], label='train loss')
plt.plot(history.history['val_loss'], label='val loss')
plt.legend()
plt.title("Model Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.show()
# Step 9: Make predictions and inverse transform
predicted = model.predict(X_test)
predicted_prices = scaler.inverse_transform(predicted)
actual_prices = scaler.inverse_transform(y_test)
# Step 10: Plot predictions
plt.figure(figsize=(12,6))
plt.plot(actual_prices[:, 1], label='Actual Close') # Close Price
plt.plot(predicted_prices[:, 1], label='Predicted Close')
plt.title("Google Stock Close Price Prediction (LSTM)")
plt.xlabel("Time")
plt.ylabel("Price")
plt.legend()
plt.show()
