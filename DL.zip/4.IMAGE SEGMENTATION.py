# U-Net Image Segmentation on Synthetic Data (Google Colab)
# Step 1: Install dependencies
#pip install -q tensorflow matplotlib
# Step 2: Import libraries
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
# Step 3: Generate synthetic image segmentation data
def generate_synthetic_data(num_samples=100, image_size=64):
    images = np.zeros((num_samples, image_size, image_size, 1), dtype=np.float32)
    masks = np.zeros((num_samples, image_size, image_size, 1), dtype=np.float32)
    for i in range(num_samples):
        radius = np.random.randint(5, 15)
        center_x = np.random.randint(radius, image_size - radius)
        center_y = np.random.randint(radius, image_size - radius)
        y, x = np.ogrid[:image_size, :image_size]
        mask = (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2
        images[i, ..., 0] = mask.astype(np.float32) + 0.1 * np.random.randn(image_size,
image_size)
        masks[i, ..., 0] = mask.astype(np.float32)
    return images, masks
# Generate synthetic data
X, y = generate_synthetic_data(200)
X_train, X_test = X[:160], X[160:]
y_train, y_test = y[:160], y[160:]
# Step 4: Define a simple U-Net model
def build_unet(input_shape=(64, 64, 1)):
    inputs = layers.Input(input_shape)
    # Encoder
    c1 = layers.Conv2D(16, (3, 3), activation='relu', padding='same')(inputs)
    c1 = layers.Conv2D(16, (3, 3), activation='relu', padding='same')(c1)
    p1 = layers.MaxPooling2D((2, 2))(c1)
    c2 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(p1)
    c2 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(c2)
    p2 = layers.MaxPooling2D((2, 2))(c2)
 # Bottleneck
    c3 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(p2)
    c3 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(c3)
 # Decoder
    u1 = layers.UpSampling2D((2, 2))(c3)
    u1 = layers.Concatenate()([u1, c2])
    c4 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(u1)
    c4 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(c4)
    u2 = layers.UpSampling2D((2, 2))(c4)
    u2 = layers.Concatenate()([u2, c1])
    c5 = layers.Conv2D(16, (3, 3), activation='relu', padding='same')(u2)
    c5 = layers.Conv2D(16, (3, 3), activation='relu', padding='same')(c5)
    outputs = layers.Conv2D(1, (1, 1), activation='sigmoid')(c5)
    model = models.Model(inputs, outputs)
    return model
# Step 5: Compile and train the model
model = build_unet()
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
history = model.fit(X_train, y_train, epochs=10, batch_size=16, validation_split=0.1)
# Step 6: Evaluate and visualize results
def visualize_predictions(images, masks, predictions, num=5):
    plt.figure(figsize=(12, num * 3))
    for i in range(num):
        plt.subplot(num, 3, i * 3 + 1)
        plt.title("Input")
        plt.imshow(images[i].squeeze(), cmap='gray')
        plt.axis('off')
        plt.subplot(num, 3, i * 3 + 2)
        plt.title("Ground Truth")    
        plt.imshow(masks[i].squeeze(), cmap='gray')
        plt.axis('off')
        plt.subplot(num, 3, i * 3 + 3)
        plt.title("Prediction")
        plt.imshow(predictions[i].squeeze() > 0.5, cmap='gray')
        plt.axis('off')
    plt.tight_layout()
    plt.show()
# Predict on test set
preds = model.predict(X_test)
visualize_predictions(X_test, y_test, preds)