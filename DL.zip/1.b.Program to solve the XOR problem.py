import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
# XOR Input and Output Data
x_train = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_train = np.array([[0], [1], [1], [0]])
# Define a simple Neural Network model
model = keras.Sequential([
 layers.Dense(4, activation='relu', input_shape=(2,)),
 layers.Dense(1, activation='sigmoid')
])
# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
# Train the model
model.fit(x_train, y_train, epochs=500, verbose=0)
# Evaluate the model
loss, accuracy = model.evaluate(x_train, y_train)
print(f"Training Accuracy: {accuracy * 100:.2f}%")
# Predict the outputs for XOR inputs
predictions = model.predict(x_train)
print("\nPredictions:")
for i, pred in enumerate(predictions):
 print(f"Input: {x_train[i]} => Predicted: {round(pred[0])}, Actual: {y_train[i][0]}")