import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
# Generate a toy dataset: House size (sq ft) vs Price ($1000s)
np.random.seed(42)
house_size = np.linspace(500, 4000, 100).reshape(-1, 1).astype(np.float32) # House size in sq ft
house_price = 50 + 0.1 * house_size + np.random.normal(0, 10, (100, 1)).astype(np.float32)
# Price in $1000s
# Normalize data
house_size_mean = np.mean(house_size)
house_size_std = np.std(house_size)
house_price_mean = np.mean(house_price)
house_price_std = np.std(house_price)
house_size_norm = (house_size - house_size_mean) / house_size_std
house_price_norm = (house_price - house_price_mean) / house_price_std
# Define model parameters

W = tf.Variable(tf.random.normal([1, 1], dtype=tf.float32))
b = tf.Variable(tf.random.normal([1], dtype=tf.float32))
# Define linear regression model
def linear_regression(X):
    return tf.matmul(X, W) + b
# Define loss function (Mean Squared Error)
def loss_fn(y_true, y_pred):
    return tf.reduce_mean(tf.square(y_true - y_pred))
# Define optimizer
optimizer = tf.optimizers.SGD(learning_rate=0.01)
# Training function
def train_step(X, y):
    with tf.GradientTape() as tape:
        y_pred = linear_regression(X)
        loss = loss_fn(y, y_pred)
    gradients = tape.gradient(loss, [W, b])
    optimizer.apply_gradients(zip(gradients, [W, b]))
    return loss
# Training loop
epochs = 200
loss_history = []
for epoch in range(epochs):
    loss = train_step(house_size_norm, house_price_norm)
    loss_history.append(loss.numpy())
    if epoch % 20 == 0:
        print(f"Epoch {epoch}, Loss: {loss.numpy():.4f}")
# Plot Loss Function
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(range(epochs), loss_history, label='Loss', color='blue')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.legend()
# Plot the Learned Linear Relationship
plt.subplot(1, 2, 2)
plt.scatter(house_size, house_price, label='Data', color='gray')

plt.plot(house_size, (linear_regression(house_size_norm).numpy() * house_price_std) +
house_price_mean, color='red', label='Fitted Line')
plt.xlabel('House Size (sq ft)')
plt.ylabel('House Price ($1000s)')
plt.title('Learned Linear Relationship')
plt.legend()
plt.show()
print(f"Trained Weight: {W.numpy()[0][0]:.4f}, Bias: {b.numpy()[0]:.4f}")
# Predict new data points
new_house_sizes = np.array([[750], [1500], [3000], [4500]], dtype=np.float32) # Example new house sizes
new_house_sizes_norm = (new_house_sizes - house_size_mean) / house_size_std #
#Normalize new data
predicted_prices_norm = linear_regression(new_house_sizes_norm).numpy() # Predict
predicted_prices = (predicted_prices_norm * house_price_std) + house_price_mean #
#De-normalize
# Print predictions
for size, price in zip(new_house_sizes.flatten(), predicted_prices.flatten()):
    print(f"Predicted price for house size {size} sq ft: ${price * 1000:.2f}")



