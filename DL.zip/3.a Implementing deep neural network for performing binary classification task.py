import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
# Generate Sample Data (Binary Classification)
np.random.seed(42)
x_train = np.random.rand(1000, 2)
y_train = (x_train[:, 0] + x_train[:, 1] > 1).astype(int)
x_test = np.random.rand(200, 2)
y_test = (x_test[:, 0] + x_test[:, 1] > 1).astype(int)
# Define a Simple Deep Neural Network Model
model = keras.Sequential([
layers.Dense(16, activation='relu', input_shape=(2,)),
layers.Dense(8, activation='relu'),
layers.Dense(1, activation='sigmoid')
])
# Compile the Model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
# Train the Model
model.fit(x_train, y_train, epochs=20, batch_size=32, validation_split=0.2)
# Evaluate on Test Data
loss, accuracy = model.evaluate(x_test, y_test)
print(f"Test Accuracy: {accuracy * 100:.2f}%")
# Predict on Test Data
predictions = (model.predict(x_test) > 0.5).astype(int)
print("\nSample Predictions:")
print(predictions[:10].flatten())