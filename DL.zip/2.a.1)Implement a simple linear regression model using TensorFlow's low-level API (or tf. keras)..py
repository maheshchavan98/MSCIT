import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# Generate sample data
np.random.seed(42)
X_train = np.linspace(0, 10, 100).reshape(-1, 1).astype(np.float32)
y_train = 2.5 * X_train + np.random.normal(0, 2, (100, 1)).astype(np.float32)  # y = 2.5x + noise

# Define model parameters
W = tf.Variable(tf.random.normal([1, 1], dtype=tf.float32))
b = tf.Variable(tf.random.normal([1], dtype=tf.float32))

# Define linear regression model
def linear_regression(X):
    return tf.matmul(X, W) + b

# Define loss function (Mean Squared Error)
def loss_fn(y_true, y_pred):
    return tf.reduce_mean(tf.square(y_true - y_pred))

# Define optimizer
optimizer = tf.optimizers.SGD(learning_rate=0.01)

# Training function
def train_step(X, y):
    with tf.GradientTape() as tape:
        y_pred = linear_regression(X)
        loss = loss_fn(y, y_pred)
    gradients = tape.gradient(loss, [W, b])
    optimizer.apply_gradients(zip(gradients, [W, b]))
    return loss

# Training loop
epochs = 200
loss_history = []

for epoch in range(epochs):
    loss = train_step(X_train, y_train)
    loss_history.append(loss.numpy())

    if epoch % 20 == 0:
        print(f"Epoch {epoch}, Loss: {loss.numpy():.4f}")

# Plot loss
plt.plot(range(epochs), loss_history, label='Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.legend()
plt.show()

# Plot regression line
plt.scatter(X_train, y_train, label='Data')
plt.plot(X_train, linear_regression(X_train).numpy(), color='red', label='Fitted Line')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Linear Regression Fit')
plt.legend()
plt.show()

# Final parameters
print(f"Trained Weight: {W.numpy()[0][0]:.4f}, Bias: {b.numpy()[0]:.4f}")