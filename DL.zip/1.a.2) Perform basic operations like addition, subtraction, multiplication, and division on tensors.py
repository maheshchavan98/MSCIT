# Import PyTorch
import torch

def create_tensor(shape, dtype=torch.float32):
    # Create tensor with given shape and datatype
    tensor = torch.zeros(shape, dtype=dtype)
    print(f"Tensor with shape {shape} and datatype {dtype} created:")
    print(tensor)
    return tensor


def tensor_operations():
    # Create two example tensors
    tensor1 = torch.tensor([[1, 2], [3, 4]], dtype=torch.float32)
    tensor2 = torch.tensor([[5, 6], [7, 8]], dtype=torch.float32)

    print("Tensor 1:")
    print(tensor1)

    print("\nTensor 2:")
    print(tensor2)

    # Addition
    addition_result = torch.add(tensor1, tensor2)
    print("\nAddition Result:")
    print(addition_result)

    # Subtraction
    subtraction_result = torch.sub(tensor1, tensor2)
    print("\nSubtraction Result:")
    print(subtraction_result)

    # Multiplication (element-wise)
    multiplication_result = torch.mul(tensor1, tensor2)
    print("\nMultiplication Result:")
    print(multiplication_result)

    # Division (element-wise)
    division_result = torch.div(tensor1, tensor2)
    print("\nDivision Result:")
    print(division_result)


# Call the function
tensor_operations()